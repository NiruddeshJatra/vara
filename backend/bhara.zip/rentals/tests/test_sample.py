import unittest

class RentalsSampleTest(unittest.TestCase):
    def test_dummy(self):
        self.assertTrue(True)

if __name__ == '__main__':
    unittest.main()
